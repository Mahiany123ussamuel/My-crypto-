import React, { useEffect, useState } from "react";

export default function CryptoNewsApp() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/.netlify/functions/getNews")
      .then(res => res.json())
      .then(data => {
        setNews(data.Data || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredNews = news.filter(article =>
    article.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6', padding: '1rem' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', textAlign: 'center', marginBottom: '1rem' }}>
        Crypto Market Stories
      </h1>
      <div style={{ maxWidth: '600px', margin: '0 auto', marginBottom: '1.5rem' }}>
        <input
          type="text"
          placeholder="Search news..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ width: '100%', padding: '0.5rem', fontSize: '1rem' }}
        />
      </div>
      <div style={{ maxWidth: '800px', margin: '0 auto', display: 'grid', gap: '1rem' }}>
        {loading ? (
          <p style={{ textAlign: 'center' }}>Loading news...</p>
        ) : filteredNews.length > 0 ? (
          filteredNews.map((article, index) => (
            <div key={index} style={{ background: 'white', padding: '1rem', borderRadius: '0.5rem', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <h2 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>{article.title}</h2>
              <p style={{ fontSize: '0.9rem', color: '#4B5563', marginBottom: '0.5rem' }}>{article.body.slice(0, 150)}...</p>
              <a href={article.url} target="_blank" style={{ color: '#3B82F6', textDecoration: 'underline' }} rel="noreferrer">
                Read more
              </a>
            </div>
          ))
        ) : (
          <p style={{ textAlign: 'center' }}>No news found.</p>
        )}
      </div>
    </div>
  );
}
