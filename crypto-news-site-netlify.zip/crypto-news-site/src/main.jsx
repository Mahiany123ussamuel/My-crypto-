import React from "react";
import ReactDOM from "react-dom/client";
import CryptoNewsApp from "./App";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CryptoNewsApp />
  </React.StrictMode>
);
